from app import create_app
import config

app = create_app()

if __name__ == "__main__":
    # use_reloader=False agar poller data sensor tidak berjalan dua kali
    app.run(host="127.0.0.1", port=config.PORT, debug=True, use_reloader=False)
