import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from app import create_app  # noqa: E402


@pytest.fixture
def client(tmp_path):
    app = create_app({
        "TESTING": True,
        "START_POLLER": False,
        "DB_PATH": str(tmp_path / "test.db"),
    })
    return app.test_client()
