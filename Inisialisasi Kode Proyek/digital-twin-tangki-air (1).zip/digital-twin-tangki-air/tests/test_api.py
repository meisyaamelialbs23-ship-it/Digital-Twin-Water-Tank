GOOD = {"level_cm": 100, "temperature_c": 27, "ph": 7.2, "turbidity_ntu": 1.5}


def test_default_config_exists(client):
    cfg = client.get("/api/tank-config").get_json()
    assert cfg["capacity_l"] == 1000 and cfg["height_cm"] == 150


def test_update_config_and_validation(client):
    ok = client.put("/api/tank-config", json={
        "name": "Tangki B", "capacity_l": 500, "height_cm": 100, "diameter_cm": 80})
    assert ok.status_code == 200 and ok.get_json()["name"] == "Tangki B"
    bad = client.put("/api/tank-config", json={
        "capacity_l": -1, "height_cm": 100, "diameter_cm": 80})
    assert bad.status_code == 400


def test_post_sensor_stores_and_computes_level(client):
    res = client.post("/api/sensor", json=GOOD)
    assert res.status_code == 201
    reading = res.get_json()["reading"]
    assert round(reading["level_pct"], 1) == 66.7
    latest = client.get("/api/sensor/latest").get_json()
    assert latest["reading"]["id"] == reading["id"]


def test_sensor_validation(client):
    res = client.post("/api/sensor", json={**GOOD, "ph": 20})
    assert res.status_code == 400
    res = client.post("/api/sensor", json={"level_cm": 10})
    assert res.status_code == 400


def test_low_level_creates_single_notification(client):
    low = {**GOOD, "level_cm": 10}
    client.post("/api/sensor", json=low)
    client.post("/api/sensor", json=low)  # dalam masa jeda -> tidak dobel
    notifs = client.get("/api/notifications").get_json()
    assert [n["kind"] for n in notifs] == ["level_low"]


def test_history_filter(client):
    client.post("/api/sensor", json=GOOD)
    assert len(client.get("/api/history").get_json()) == 1
    assert client.get("/api/history?start=2999-01-01").get_json() == []
    assert client.get("/api/history?end=2000-01-01").get_json() == []


def test_simulator_returns_valid_reading(client):
    data = client.get("/sim/sensor").get_json()
    assert set(data) == {"level_cm", "temperature_c", "ph", "turbidity_ntu"}
    assert client.post("/api/sensor", json=data).status_code == 201


def test_dashboard_page(client):
    assert client.get("/").status_code == 200
