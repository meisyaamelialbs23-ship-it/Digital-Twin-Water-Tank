# Digital Twin Tangki Air

Kerangka dasar (boilerplate) proyek **Perancangan Digital Twin Tangki Air untuk Monitoring Ketinggian dan Kondisi Air Secara Real-Time**.
Berisi struktur folder, inisialisasi database, API simulasi sensor, dan dashboard awal yang sudah bisa dijalankan.

**Teknologi:** Python 3.10+, Flask, SQLite, HTML/CSS/JavaScript (tanpa framework tambahan).

## Menjalankan

```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate
# Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

Buka http://127.0.0.1:5000. Database `data/tangki.db` dibuat otomatis saat pertama dijalankan.
Data simulasi masuk setiap 5 detik (atur di `config.py`).

## Menjalankan tes

```bash
python -m pytest
```

## Struktur folder

```
digital-twin-tangki-air/
├── run.py                 # titik masuk aplikasi
├── config.py              # pengaturan, ambang batas notifikasi, sumber data sensor
├── requirements.txt
├── app/
│   ├── __init__.py        # create_app()
│   ├── db.py              # koneksi & inisialisasi SQLite
│   ├── schema.sql         # tabel + data awal
│   ├── routes.py          # halaman dan REST API
│   ├── ingest.py          # validasi, simpan data sensor, poller API simulasi
│   ├── anomaly.py         # aturan deteksi kondisi kritis
│   ├── simulator.py       # API simulasi sensor (/sim/sensor)
│   ├── templates/index.html
│   └── static/{css,js}/
├── data/                  # file database (tidak masuk git)
├── docs/                  # dokumen Sprint 1
└── tests/
```

## Endpoint

| Method | URL | Fungsi | PBI |
| --- | --- | --- | --- |
| GET / PUT | `/api/tank-config` | Baca / ubah konfigurasi tangki | 01, 08 |
| POST | `/api/sensor` | Input data sensor (JSON) | 02, 09 |
| GET | `/api/sensor/latest` | Data terakhir + peringatan aktif | 03, 04 |
| GET | `/api/history?start=&end=&limit=` | Riwayat, bisa difilter waktu | 06, 07 |
| GET | `/api/notifications` | Catatan notifikasi | 05, 10 |
| GET | `/sim/sensor` | API simulasi sensor | 11 |

Contoh input manual:

```bash
curl -X POST http://127.0.0.1:5000/api/sensor -H "Content-Type: application/json" \
  -d '{"level_cm": 30, "temperature_c": 27, "ph": 7.1, "turbidity_ntu": 2}'
```

## Status terhadap Sprint 1 Backlog

Kerangka ini sudah memuat versi dasar dari PBI-01 sampai PBI-11 (skema database, simulator, penyimpanan,
deteksi anomali, dashboard, riwayat). Tugas tim selanjutnya adalah menyempurnakan, misalnya
visualisasi tangki yang lebih detail (T-11), indikator kualitas air (T-14), dan pengujian lebih lengkap (T-19).

## Catatan

- Belum ada login; tabel `users` sudah disiapkan untuk PBI-12 (Sprint 2).
- Waktu disimpan sesuai jam lokal komputer server.
- Jika sensor fisik sudah ada, ubah `SENSOR_API_URL` di `config.py` atau kirim data langsung ke `POST /api/sensor`.
