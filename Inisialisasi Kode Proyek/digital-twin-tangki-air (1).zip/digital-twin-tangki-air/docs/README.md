# Folder Dokumen Sprint 1

| Dokumen | Status |
| --- | --- |
| Project Charter | Letakkan file di sini (`Project_Charter.docx`) |
| Perhitungan Function Point | `Perhitungan_Function_Point_Sprint_1.md` |
| Product Backlog & Sprint 1 Backlog | `Product_Backlog_dan_Sprint_1_Backlog.md` |
| Rancangan UX/UI (wireframe/mockup) | Letakkan ekspor gambar/PDF di sini |
| Rancangan sistem (flowchart, arsitektur, ERD) | Letakkan ekspor gambar/PDF di sini |
