"""Konfigurasi utama aplikasi Digital Twin Tangki Air."""
import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
PORT = 5000

# Database
DB_PATH = os.path.join(BASE_DIR, "data", "tangki.db")

# Sumber data sensor (API simulasi bawaan proyek ini; ganti ke sensor asli di Sprint berikutnya)
SENSOR_API_URL = f"http://127.0.0.1:{PORT}/sim/sensor"
START_POLLER = True
POLL_INTERVAL_S = 5

# Ambang batas notifikasi
LEVEL_LOW_PCT = 20
LEVEL_HIGH_PCT = 90
TEMP_MIN_C = 15
TEMP_MAX_C = 35
PH_MIN = 6.5
PH_MAX = 8.5
TURBIDITY_MAX_NTU = 5

# Jeda minimal (detik) sebelum notifikasi jenis yang sama dicatat lagi
NOTIF_COOLDOWN_S = 60
