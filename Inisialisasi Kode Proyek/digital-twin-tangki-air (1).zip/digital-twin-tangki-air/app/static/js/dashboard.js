const $ = (s) => document.querySelector(s);
const REFRESH_MS = 3000;
const T = { top: 20, bottom: 260 }; // batas atas & bawah tangki pada SVG

async function api(url, opts) {
  const res = await fetch(url, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Terjadi kesalahan.");
  return data;
}

function drawWater(pct) {
  const h = ((T.bottom - T.top) * pct) / 100;
  const water = $("#water");
  water.setAttribute("y", T.bottom - h);
  water.setAttribute("height", h);
  water.classList.toggle("low", pct < 20);
}

function renderLatest({ reading, alerts }) {
  if (!reading) return;
  drawWater(reading.level_pct);
  $("#level-pct").textContent = `${reading.level_pct.toFixed(0)}%`;
  $("#level-detail").textContent = `${reading.level_cm.toFixed(1)} cm`;
  $("#r-temp").textContent = `${reading.temperature_c.toFixed(1)} °C`;
  $("#r-ph").textContent = reading.ph.toFixed(2);
  $("#r-turb").textContent = `${reading.turbidity_ntu.toFixed(1)} NTU`;
  $("#r-vol").textContent = `${reading.volume_l.toFixed(0)} L`;
  $("#updated").textContent = `Data terakhir: ${reading.recorded_at}`;

  const badge = $("#status");
  const level = alerts.some((a) => a.severity === "critical") ? "critical"
              : alerts.length ? "warning" : "ok";
  badge.className = `badge ${level}`;
  badge.textContent = { ok: "Normal", warning: "Perlu perhatian", critical: "Kritis" }[level];
}

function renderNotifs(items) {
  const ul = $("#notifs");
  ul.innerHTML = "";
  if (!items.length) {
    ul.innerHTML = '<li class="muted">Belum ada notifikasi.</li>';
    return;
  }
  for (const n of items) {
    const li = document.createElement("li");
    li.className = n.severity;
    const time = document.createElement("time");
    time.textContent = n.created_at;
    li.append(time, n.message);
    ul.append(li);
  }
}

function renderHistory(rows) {
  const body = $("#hist-body");
  body.innerHTML = "";
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="6" class="muted">Tidak ada data pada rentang ini.</td></tr>';
    return;
  }
  for (const r of rows) {
    const tr = document.createElement("tr");
    [r.recorded_at, `${r.level_pct.toFixed(0)}% (${r.level_cm.toFixed(1)} cm)`,
     `${r.volume_l.toFixed(0)} L`, `${r.temperature_c.toFixed(1)} °C`,
     r.ph.toFixed(2), `${r.turbidity_ntu.toFixed(1)} NTU`].forEach((v) => {
      const td = document.createElement("td");
      td.textContent = v;
      tr.append(td);
    });
    body.append(tr);
  }
}

async function loadHistory() {
  const p = new URLSearchParams();
  const f = new FormData($("#hist-form"));
  for (const k of ["start", "end"]) if (f.get(k)) p.set(k, f.get(k));
  p.set("limit", 50);
  renderHistory(await api(`/api/history?${p}`));
}

async function refresh() {
  try {
    renderLatest(await api("/api/sensor/latest"));
    renderNotifs(await api("/api/notifications?limit=10"));
    await loadHistory();
  } catch (e) {
    $("#updated").textContent = e.message;
  }
}

async function loadConfig() {
  const cfg = await api("/api/tank-config");
  const form = $("#cfg-form");
  for (const k of ["name", "capacity_l", "height_cm", "diameter_cm"]) form.elements[k].value = cfg[k];
  $("#tank-name").textContent = `${cfg.name} · ${cfg.capacity_l} L · tinggi ${cfg.height_cm} cm · diameter ${cfg.diameter_cm} cm`;
}

$("#cfg-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = Object.fromEntries(new FormData(e.target));
  try {
    await api("/api/tank-config", {
      method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    $("#cfg-msg").textContent = "Konfigurasi tersimpan.";
    await loadConfig();
  } catch (err) {
    $("#cfg-msg").textContent = err.message;
  }
});

$("#hist-form").addEventListener("submit", (e) => { e.preventDefault(); loadHistory(); });
$("#hist-reset").addEventListener("click", () => { $("#hist-form").reset(); loadHistory(); });

loadConfig();
refresh();
setInterval(refresh, REFRESH_MS);
