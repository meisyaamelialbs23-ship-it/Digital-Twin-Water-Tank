import os
import sqlite3

from flask import current_app, g


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(_exc=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db():
    """Membuat tabel (jika belum ada) dan mengisi data awal."""
    os.makedirs(os.path.dirname(current_app.config["DB_PATH"]), exist_ok=True)
    conn = get_db()
    with current_app.open_resource("schema.sql") as f:
        conn.executescript(f.read().decode("utf-8"))
    conn.commit()


def init_app(app):
    app.teardown_appcontext(close_db)
