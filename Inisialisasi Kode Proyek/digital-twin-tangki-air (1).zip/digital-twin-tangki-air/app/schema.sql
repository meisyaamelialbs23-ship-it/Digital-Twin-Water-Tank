-- Skema database Sprint 1 (PBI-08, PBI-09, PBI-10)

CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    username   TEXT NOT NULL UNIQUE,
    role       TEXT NOT NULL DEFAULT 'operator',
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS tank_config (
    id          INTEGER PRIMARY KEY CHECK (id = 1),
    name        TEXT NOT NULL,
    capacity_l  REAL NOT NULL CHECK (capacity_l > 0),
    height_cm   REAL NOT NULL CHECK (height_cm > 0),
    diameter_cm REAL NOT NULL CHECK (diameter_cm > 0),
    updated_at  TEXT NOT NULL DEFAULT (datetime('now', 'localtime'))
);

CREATE TABLE IF NOT EXISTS sensor_readings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    recorded_at   TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    level_cm      REAL NOT NULL,
    level_pct     REAL NOT NULL,
    volume_l      REAL NOT NULL,
    temperature_c REAL NOT NULL,
    ph            REAL NOT NULL,
    turbidity_ntu REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_readings_time ON sensor_readings (recorded_at);

CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now', 'localtime')),
    kind       TEXT NOT NULL,
    severity   TEXT NOT NULL,
    message    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_kind_time ON notifications (kind, created_at);

-- Data awal
INSERT OR IGNORE INTO tank_config (id, name, capacity_l, height_cm, diameter_cm)
VALUES (1, 'Tangki Utama', 1000, 150, 100);

INSERT OR IGNORE INTO users (username, role) VALUES ('admin', 'admin');
