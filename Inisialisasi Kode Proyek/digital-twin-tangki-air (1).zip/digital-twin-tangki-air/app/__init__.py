from flask import Flask

from . import db


def create_app(overrides=None):
    app = Flask(__name__)
    app.config.from_object("config")
    if overrides:
        app.config.update(overrides)

    db.init_app(app)

    from .routes import bp
    from .simulator import sim_bp

    app.register_blueprint(bp)
    app.register_blueprint(sim_bp)

    with app.app_context():
        db.init_db()

    if app.config.get("START_POLLER"):
        from .ingest import start_poller

        start_poller(app)

    return app
