"""API simulasi sensor tangki air (PBI-11). Diganti sensor fisik di Sprint berikutnya."""
import random

from flask import Blueprint, jsonify

from .db import get_db

sim_bp = Blueprint("sim", __name__, url_prefix="/sim")
_state = {"level": None, "direction": -1}


@sim_bp.get("/sensor")
def sensor():
    height = get_db().execute(
        "SELECT height_cm FROM tank_config WHERE id = 1").fetchone()["height_cm"]

    if _state["level"] is None or _state["level"] > height:
        _state["level"] = height * 0.7

    _state["level"] += _state["direction"] * random.uniform(0.5, 3.0)
    if _state["level"] <= height * 0.12:
        _state["direction"] = 1
    elif _state["level"] >= height * 0.95:
        _state["direction"] = -1
    _state["level"] = max(0.0, min(height, _state["level"]))

    turbidity = random.uniform(0.5, 3.0)
    if random.random() < 0.05:  # sesekali air keruh agar notifikasi bisa dicoba
        turbidity = random.uniform(6.0, 9.0)

    return jsonify(
        level_cm=round(_state["level"], 1),
        temperature_c=round(random.gauss(27.5, 1.2), 1),
        ph=round(random.gauss(7.2, 0.25), 2),
        turbidity_ntu=round(turbidity, 1),
    )
