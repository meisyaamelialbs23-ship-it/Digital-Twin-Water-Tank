"""Aturan deteksi kondisi kritis / anomali (PBI-05)."""
from flask import current_app


def check_reading(reading):
    """Mengembalikan daftar peringatan untuk satu pembacaan sensor."""
    c = current_app.config
    alerts = []

    if reading["level_pct"] < c["LEVEL_LOW_PCT"]:
        alerts.append(("level_low", "critical",
                       f"Level air rendah ({reading['level_pct']:.0f}%)."))
    elif reading["level_pct"] > c["LEVEL_HIGH_PCT"]:
        alerts.append(("level_high", "warning",
                       f"Tangki hampir penuh ({reading['level_pct']:.0f}%)."))

    if not c["TEMP_MIN_C"] <= reading["temperature_c"] <= c["TEMP_MAX_C"]:
        alerts.append(("temp", "warning",
                       f"Suhu air di luar batas ({reading['temperature_c']:.1f} °C)."))

    if not c["PH_MIN"] <= reading["ph"] <= c["PH_MAX"]:
        alerts.append(("ph", "critical",
                       f"pH air di luar batas ({reading['ph']:.2f})."))

    if reading["turbidity_ntu"] > c["TURBIDITY_MAX_NTU"]:
        alerts.append(("turbidity", "warning",
                       f"Air keruh ({reading['turbidity_ntu']:.1f} NTU)."))

    return [{"kind": k, "severity": s, "message": m} for k, s, m in alerts]
