"""Input data sensor, penyimpanan rekaman, dan pengambilan data dari API simulasi
(PBI-02, PBI-09, PBI-11)."""
import json
import logging
import threading
import time
import urllib.request

from flask import current_app

from .anomaly import check_reading
from .db import get_db

log = logging.getLogger(__name__)
FIELDS = ("level_cm", "temperature_c", "ph", "turbidity_ntu")


class ValidationError(ValueError):
    pass


def validate(payload):
    if not isinstance(payload, dict):
        raise ValidationError("Data harus berupa objek JSON.")
    data = {}
    for f in FIELDS:
        try:
            data[f] = float(payload[f])
        except (KeyError, TypeError, ValueError):
            raise ValidationError(f"Field '{f}' wajib diisi dengan angka.")
    if data["level_cm"] < 0:
        raise ValidationError("level_cm tidak boleh negatif.")
    if not 0 <= data["ph"] <= 14:
        raise ValidationError("ph harus di antara 0 dan 14.")
    if data["turbidity_ntu"] < 0:
        raise ValidationError("turbidity_ntu tidak boleh negatif.")
    return data


def get_tank_config(conn):
    return dict(conn.execute("SELECT * FROM tank_config WHERE id = 1").fetchone())


def _store_notification(conn, alert):
    cooldown = f"-{int(current_app.config['NOTIF_COOLDOWN_S'])} seconds"
    recent = conn.execute(
        "SELECT 1 FROM notifications WHERE kind = ? "
        "AND created_at >= datetime('now', 'localtime', ?)",
        (alert["kind"], cooldown),
    ).fetchone()
    if recent is None:
        conn.execute(
            "INSERT INTO notifications (kind, severity, message) VALUES (?, ?, ?)",
            (alert["kind"], alert["severity"], alert["message"]),
        )


def save_reading(payload):
    """Validasi, simpan rekaman sensor, lalu jalankan deteksi anomali."""
    data = validate(payload)
    conn = get_db()
    cfg = get_tank_config(conn)

    pct = max(0.0, min(100.0, data["level_cm"] / cfg["height_cm"] * 100))
    volume = cfg["capacity_l"] * pct / 100

    cur = conn.execute(
        "INSERT INTO sensor_readings "
        "(level_cm, level_pct, volume_l, temperature_c, ph, turbidity_ntu) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (data["level_cm"], pct, volume, data["temperature_c"], data["ph"],
         data["turbidity_ntu"]),
    )
    row = conn.execute("SELECT * FROM sensor_readings WHERE id = ?",
                       (cur.lastrowid,)).fetchone()
    reading = dict(row)
    alerts = check_reading(reading)
    for a in alerts:
        _store_notification(conn, a)
    conn.commit()
    return reading, alerts


def fetch_sensor():
    """Mengambil satu pembacaan dari API sensor (simulasi)."""
    url = current_app.config["SENSOR_API_URL"]
    with urllib.request.urlopen(url, timeout=5) as resp:
        return json.loads(resp.read().decode("utf-8"))


def start_poller(app):
    """Menjalankan thread yang mengambil data sensor secara berkala."""
    def loop():
        time.sleep(2)  # tunggu server siap
        while True:
            try:
                with app.app_context():
                    save_reading(fetch_sensor())
            except Exception as exc:  # jangan hentikan thread karena satu kegagalan
                log.warning("Gagal mengambil data sensor: %s", exc)
            time.sleep(app.config["POLL_INTERVAL_S"])

    threading.Thread(target=loop, daemon=True, name="sensor-poller").start()
