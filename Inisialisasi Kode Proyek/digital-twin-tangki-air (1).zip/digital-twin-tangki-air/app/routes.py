"""Halaman dan REST API Sprint 1."""
from flask import Blueprint, jsonify, render_template, request

from .anomaly import check_reading
from .db import get_db
from .ingest import ValidationError, get_tank_config, save_reading

bp = Blueprint("main", __name__)


@bp.get("/")
def dashboard():
    return render_template("index.html")


# --- Konfigurasi tangki (PBI-01, PBI-08) ---
@bp.get("/api/tank-config")
def read_tank_config():
    return jsonify(get_tank_config(get_db()))


@bp.put("/api/tank-config")
def update_tank_config():
    body = request.get_json(silent=True) or {}
    try:
        values = {k: float(body[k]) for k in ("capacity_l", "height_cm", "diameter_cm")}
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Kapasitas, tinggi, dan diameter wajib diisi dengan angka."), 400
    if any(v <= 0 for v in values.values()):
        return jsonify(error="Kapasitas, tinggi, dan diameter harus lebih dari 0."), 400

    name = str(body.get("name", "")).strip() or "Tangki Utama"
    conn = get_db()
    conn.execute(
        "UPDATE tank_config SET name = ?, capacity_l = ?, height_cm = ?, diameter_cm = ?, "
        "updated_at = datetime('now', 'localtime') WHERE id = 1",
        (name, values["capacity_l"], values["height_cm"], values["diameter_cm"]),
    )
    conn.commit()
    return jsonify(get_tank_config(conn))


# --- Data sensor (PBI-02, PBI-03, PBI-04) ---
@bp.post("/api/sensor")
def post_sensor():
    try:
        reading, alerts = save_reading(request.get_json(silent=True))
    except ValidationError as exc:
        return jsonify(error=str(exc)), 400
    return jsonify(reading=reading, alerts=alerts), 201


@bp.get("/api/sensor/latest")
def latest_sensor():
    row = get_db().execute(
        "SELECT * FROM sensor_readings ORDER BY id DESC LIMIT 1").fetchone()
    if row is None:
        return jsonify(reading=None, alerts=[])
    reading = dict(row)
    return jsonify(reading=reading, alerts=check_reading(reading))


# --- Riwayat & pencarian rentang waktu (PBI-06, PBI-07) ---
def _normalize_time(value, end=False):
    value = value.strip().replace("T", " ")
    if len(value) == 10:  # hanya tanggal
        return value + (" 23:59:59" if end else " 00:00:00")
    if len(value) == 16:  # tanggal + jam:menit
        return value + (":59" if end else ":00")
    return value


@bp.get("/api/history")
def history():
    sql, args = "SELECT * FROM sensor_readings WHERE 1=1", []
    if request.args.get("start"):
        sql += " AND recorded_at >= ?"
        args.append(_normalize_time(request.args["start"]))
    if request.args.get("end"):
        sql += " AND recorded_at <= ?"
        args.append(_normalize_time(request.args["end"], end=True))
    try:
        limit = max(1, min(int(request.args.get("limit", 100)), 1000))
    except ValueError:
        limit = 100
    sql += " ORDER BY id DESC LIMIT ?"
    args.append(limit)
    rows = get_db().execute(sql, args).fetchall()
    return jsonify([dict(r) for r in rows])


# --- Notifikasi (PBI-05, PBI-10) ---
@bp.get("/api/notifications")
def notifications():
    try:
        limit = max(1, min(int(request.args.get("limit", 20)), 200))
    except ValueError:
        limit = 20
    rows = get_db().execute(
        "SELECT * FROM notifications ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return jsonify([dict(r) for r in rows])
